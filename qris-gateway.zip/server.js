require('dotenv').config();
const express = require('express');
const cors = require('cors');
const puppeteer = require('puppeteer'); 
const fs = require('fs');
const path = require('path');

if (!process.env.BCA_EMAIL || !process.env.BCA_PASSWORD) {
    console.error("\n❌ [FATAL ERROR] Kredensial BCA tidak ditemukan di .env!");
    process.exit(1);
}

// ==========================================
// 1. KONFIGURASI & UTILITAS
// ==========================================
const PORT = process.env.PORT || 3000;
const SECRET_KEY = process.env.API_SECRET_KEY;
const REPORTS_DIR = path.join(__dirname, 'reports');

if (!fs.existsSync(REPORTS_DIR)) fs.mkdirSync(REPORTS_DIR);

const delay = (ms) => new Promise(res => setTimeout(res, ms));
const getLogTime = () => new Date().toLocaleTimeString('id-ID');
const getCurrentDate = () => {
    const today = new Date();
    return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
};
const getDailyCsvPath = () => path.join(REPORTS_DIR, `Rekap_QRIS_${getCurrentDate()}.csv`);

const processedRRNs = new Set();

// ==========================================
// 2. SISTEM DATABASE CSV HARIAN
// ==========================================
const initDailyCsv = () => {
    const csvPath = getDailyCsvPath();
    if (!fs.existsSync(csvPath)) {
        fs.writeFileSync(csvPath, '"Tanggal","Waktu","RRN","Nominal","Sumber_Dana"\n');
        processedRRNs.clear();
    } else {
        const lines = fs.readFileSync(csvPath, 'utf-8').split('\n');
        lines.forEach(line => {
            const parts = line.split('","');
            if (parts.length >= 3) {
                const rrnClean = parts[2].replace(/"/g, '').trim();
                if (rrnClean && rrnClean !== 'RRN') processedRRNs.add(rrnClean);
            }
        });
    }
};

const readDailyCsv = (dateQuery = getCurrentDate()) => {
    const targetCsv = path.join(REPORTS_DIR, `Rekap_QRIS_${dateQuery}.csv`);
    if (!fs.existsSync(targetCsv)) return [];
    
    const lines = fs.readFileSync(targetCsv, 'utf-8').trim().split('\n');
    const data = [];
    for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const parts = lines[i].split('","').map(p => p.replace(/"/g, '').trim());
        if (parts.length >= 4) {
            data.push({
                tanggal: parts[0], waktu: parts[1], rrn: parts[2],
                nominal: parseInt(parts[3], 10), sumber_dana: parts[4] || ''
            });
        }
    }
    return data.reverse(); 
};

// ==========================================
// 3. SERVER API REST
// ==========================================
const app = express();
app.use(express.json());
app.use(cors({ origin: '*' }));

const authenticate = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ error: 'unauthorized', message: 'Missing token' });
    if (authHeader.split(' ')[1] !== SECRET_KEY) return res.status(403).json({ error: 'forbidden', message: 'Invalid API Key' });
    next();
};

app.get('/v1/transactions/:rrn', authenticate, (req, res) => {
    try {
        const trx = readDailyCsv().find(t => t.rrn === req.params.rrn);
        if (trx) res.status(200).json({ status: 'success', data: trx });
        else res.status(404).json({ status: 'not_found', message: 'Transaction not found.' });
    } catch (err) { res.status(500).json({ error: 'server_error', message: err.message }); }
});

app.get('/v1/verify', authenticate, (req, res) => {
    try {
        const { nominal } = req.query;
        if (!nominal) return res.status(400).json({ error: 'bad_request', message: 'Nominal parameter is required.' });
        const trx = readDailyCsv().find(t => t.nominal === parseInt(nominal, 10));
        if (trx) res.status(200).json({ status: 'success', data: trx });
        else res.status(404).json({ status: 'not_found', message: 'No matching transaction found.' });
    } catch (err) { res.status(500).json({ error: 'server_error', message: err.message }); }
});

app.get('/v1/reports/download', authenticate, (req, res) => {
    const dateQuery = req.query.date || getCurrentDate();
    const targetCsv = path.join(REPORTS_DIR, `Rekap_QRIS_${dateQuery}.csv`);
    if (fs.existsSync(targetCsv)) res.download(targetCsv); 
    else res.status(404).json({ error: 'not_found', message: `Report for date ${dateQuery} not found.` });
});

app.listen(PORT, () => {
    console.log(`\n========================================================`);
    console.log(`🚀 [API] Payment Gateway Server running on port ${PORT}`);
    console.log(`========================================================\n`);
});

// ==========================================
// 4. MESIN SCRAPER (MULTIPLE ROWS, NO LIMIT)
// ==========================================
async function jalankanScraper() {
    let browser;
    let page;
    try {
        initDailyCsv(); 

        console.log(`[SCRAPER] [${getLogTime()}] STEP 1: Menyiapkan Chromium...`);
        browser = await puppeteer.launch({
            headless: "new", 
            defaultViewport: { width: 1366, height: 768 },
            args: [
                '--no-sandbox', 
                '--disable-setuid-sandbox', 
                '--disable-dev-shm-usage', 
                '--disable-gpu',           
                '--no-zygote',             
                '--disable-extensions',
                '--disable-background-networking',
                '--disable-default-apps',
                '--disable-sync',
                '--window-size=1366,768'
            ]
        });

        page = await browser.newPage();
        
        console.log(`[SCRAPER] [${getLogTime()}] STEP 2: Memblokir resource berat...`);
        await page.setRequestInterception(true);
        page.on('request', (req) => {
            if (['image', 'media', 'font'].includes(req.resourceType())) {
                req.abort();
            } else {
                req.continue();
            }
        });
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36');

        console.log(`[SCRAPER] [${getLogTime()}] STEP 3: Mengakses halaman login BCA...`);
        await page.goto('https://qr.klikbca.com/login', { waitUntil: 'domcontentloaded', timeout: 60000 });
        
        console.log(`[SCRAPER] [${getLogTime()}] STEP 4: Mengetik kredensial...`);
        await page.waitForSelector("input[type='email']", { timeout: 15000 });
        await delay(1000);
        await page.type("input[type='email']", process.env.BCA_EMAIL, { delay: 50 }); 
        await delay(500);
        await page.type("input[name='password']", process.env.BCA_PASSWORD, { delay: 50 });
        await delay(500);
        
        console.log(`[SCRAPER] [${getLogTime()}] STEP 5: Mengeklik Login...`);
        await Promise.all([
            page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 60000 }),
            page.evaluate(() => document.querySelector("button[type='submit']").click())
        ]);
        
        console.log(`[SCRAPER] [${getLogTime()}] STEP 6: Login BERHASIL! Mode pemantauan aktif.`);

        while (true) {
            initDailyCsv();

            const isLoggedOut = await page.$("input[type='email']").catch(() => null);
            if (isLoggedOut) throw new Error("Sesi ter-logout kembali ke halaman login."); 

            try {
                // Tunggu elemen baris transaksi muncul di tabel
                await page.waitForSelector('tr.table-active', { timeout: 5000 }).catch(() => null);
                
                // MENGAMBIL SEMUA BARIS TRANSAKSI DI HALAMAN (TANPA LIMIT .slice)
                const transactions = await page.evaluate(() => {
                    const rows = Array.from(document.querySelectorAll('tr.table-active'));
                    
                    return rows.map(row => {
                        const refText = row.querySelector('.reference-number') ? row.querySelector('.reference-number').innerText.trim() : '';
                        const detail = row.querySelector('.font-size-detail-trx') ? row.querySelector('.font-size-detail-trx').innerText.trim() : '';
                        const nominalText = row.querySelector('td.text-right h4') ? row.querySelector('td.text-right h4').innerText.trim() : '';

                        if (!refText || !nominalText) return null;

                        let rrn = refText.includes('|') ? refText.split('|')[0].replace('RRN:', '').trim() : refText;
                        let waktu = refText.includes('|') ? refText.split('|')[1].replace('WIB', '').trim() : '';
                        const nominal = nominalText.replace(/[^0-9]/g, '');
                        const sumberDana = detail.replace(/Menerima pembayaran dari/gi, '').replace(/(\r\n|\n|\r)/gm, " ").trim();

                        return { rrn, waktu, nominal, sumberDana };
                    }).filter(item => item !== null);
                });

                if (transactions && transactions.length > 0) {
                    // Dibalik agar baris paling bawah (transaksi paling lama di halaman tsb) dieksekusi duluan
                    transactions.reverse().forEach(dataQris => {
                        if (!processedRRNs.has(dataQris.rrn)) {
                            console.log(`\n[INFO] 💸 TRANSAKSI BARU DITEMUKAN: RRN ${dataQris.rrn} | Rp ${dataQris.nominal}`);
                            
                            const csvRow = `"${getCurrentDate()}","${dataQris.waktu}","${dataQris.rrn}","${dataQris.nominal}","${dataQris.sumberDana}"\n`;
                            fs.appendFileSync(getDailyCsvPath(), csvRow); 
                            
                            processedRRNs.add(dataQris.rrn); 
                        }
                    });
                }
            } catch (err) {
                // Abaikan jika tidak ada data saat direfresh
            } 

            // Jeda 10 - 20 detik untuk menghindari deteksi spam dari bank
            const waitTime = Math.floor(Math.random() * (20000 - 10000 + 1)) + 10000;
            console.log(`[SCRAPER] [${getLogTime()}] LOOP: Menunggu ${Math.round(waitTime/1000)} detik...`);
            await delay(waitTime); 
            
            await page.reload({ waitUntil: 'domcontentloaded', timeout: 60000 });
            await delay(2000); 
        }
    } catch (error) {
        console.log(`\n[ERROR FATAL] [${getLogTime()}] Bot crash: ${error.message}`);
        if (page) {
            try {
                const ssPath = `error_debug_${Date.now()}.png`;
                await page.screenshot({ path: ssPath, fullPage: true });
                console.log(`[DEBUG] Screenshot disimpan sebagai '${ssPath}'`);
            } catch (ssErr) {}
        }
        throw error; 
    } finally {
        if (browser) {
            await browser.close().catch(() => {});
        }
    }
}

// Watchdog
(async function watchdog() {
    while (true) {
        try {
            await jalankanScraper();
        } catch (err) {
            console.log(`\n[WATCHDOG] Restarting scraper in 10 seconds...\n`);
            await delay(10000); 
        }
    }
})();